
//adc��ʼ�������ͼ���ĺ����ļ�

#include "adc.h"

//�������ʲɼ�����
#define aptitude_trigger 500
#define time_trigger 10

ADC_HandleTypeDef hadc1;
ADC_ChannelConfTypeDef sConfig = {0};

//��ʼ������
void ADC1_Init(void)
{
	
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
	HAL_ADC_Init(&hadc1);

  sConfig.Channel = ADC_CHANNEL_12;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_480CYCLES;
	HAL_ADC_ConfigChannel(&hadc1, &sConfig);
  
}


//��ʼ��ADC��Ӧ��GPIO
void ADC_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    __HAL_RCC_ADC1_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();

    GPIO_InitStruct.Pin = GPIO_PIN_2;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
}


//��ȡADC��ֵ
uint16_t ADC_GetValue(void)
{
	
	uint16_t val;
	hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
	
	//����ADC
	HAL_ADC_Start(& hadc1);
	//�ȴ�ADC���
	while(HAL_OK != HAL_ADC_PollForConversion(&hadc1, 1));
	val= HAL_ADC_GetValue(&hadc1);
	//�ȴ�ADC���
	HAL_ADC_Stop(& hadc1);
	return val;
	
}


//���ֵλ����ȡ
uint16_t  array_max(uint16_t* array, unsigned int size)
{
	
	unsigned int i;
	unsigned int max = 0;
	for(i = 0x00; i <= size - 1; i++)
	{
		if(array[i] > max)
			max = array[i];
	}
	
	for(i = 0x00; i <= size - 1; i++)
	{
		if(array[i] == max)
			break;
	}
	
	return i;
	
}


//��Сֵλ����ȡ
uint16_t  array_min(uint16_t* array, unsigned int size)
{
	
	unsigned int i;
	unsigned int min = 8000;
	for(i = 0x00; i <= size - 1; i++)
	{
		if(array[i] < min)
			min = array[i];
	}
	
	for(i = 0x00; i <= size - 1; i++)
	{
		if(array[i] == min)
			break;
	}
	
	return i;
	
}


//��������ֵ, �������ڼ��
//maxΪ���������ֵ��max_pos����λ�ã�val_arrayΪ�洢����
uint16_t  heart_rate_calculate(uint16_t max, uint16_t max_pos, uint16_t * val_array, uint16_t size, float scale)
{
	
	int i;
	
	//����max_pos�ұ�
	for(i = max_pos; i <= size - 1; i++)
	{
		//�����ɹ�
		if(max - val_array[i] < aptitude_trigger && i - max_pos > time_trigger)
		{
			return 100 * 60 / (i - max_pos) / scale;
		}
	}
	
  //����max_pos���
	for(i = max_pos; i >= 0; i--)
	{
		if(max - val_array[i] < aptitude_trigger && max_pos - i > time_trigger)
		{
			return 100 * 60 / (max_pos - i) / scale;
		}
	}
	
	//����ʧ��
	return 0;
	
}














