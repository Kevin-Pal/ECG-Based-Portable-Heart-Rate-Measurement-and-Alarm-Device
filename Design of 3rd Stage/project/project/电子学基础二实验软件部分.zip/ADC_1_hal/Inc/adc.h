#ifndef _ADC_H_
#define _ADC_H_

#include "stm32f4xx_hal.h"

void ADC1_Init(void);
void ADC_GPIO_Init(void);
uint16_t ADC_GetValue(void);
uint16_t array_max(uint16_t* array, unsigned int size);
uint16_t array_min(uint16_t* array, unsigned int size);
uint16_t  heart_rate_calculate(uint16_t max, uint16_t max_pos, uint16_t * val_array, uint16_t siz, float scale);
#endif


